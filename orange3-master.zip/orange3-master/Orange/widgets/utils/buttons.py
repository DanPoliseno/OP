from orangewidget.utils.buttons import (
    VariableTextPushButton, SimpleButton,
)
__all__ = [
    "VariableTextPushButton", "SimpleButton"
]