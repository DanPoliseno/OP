from orangewidget.utils.saveplot import save_plot

__all__ = ["save_plot"]
