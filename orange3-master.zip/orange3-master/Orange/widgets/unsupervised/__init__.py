"""
============
Unsupervised
============

Unsupervised learning.

"""

# Category description for the widget registry

NAME = "Unsupervised"

DESCRIPTION = "Unsupervised learning."

BACKGROUND = "#CAE1EF"

ICON = "icons/Category-Unsupervised.svg"

PRIORITY = 6
